
# -*- coding: utf-8 -*-

from . import res_partner
from . import education
from . import experience
from . import skill
